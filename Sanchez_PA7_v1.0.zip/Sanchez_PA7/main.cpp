#include "FileWrapper.h"
int main(void) {
	FileWrapper F;
	F.mainMenu();
	return 0;
}